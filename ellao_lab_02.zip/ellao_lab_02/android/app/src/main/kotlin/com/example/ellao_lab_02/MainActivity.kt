package com.example.ellao_lab_02

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
