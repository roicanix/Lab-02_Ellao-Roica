import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Home(),
  )); //MaterialApp
}

class Home extends StatelessWidget {
  // const ({key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        title: Text("Ellao LAB 02"),
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent[600],
      ),
      body: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Icon (Icons.heart_broken),
            Container(
              color: Colors.blueAccent,
              padding: EdgeInsets.all(30.0),
              child: Text('L'),
            ),
            Icon (Icons.heart_broken),
            Container(
              color: Colors.red,
              padding: EdgeInsets.all(30.0),
              child: Text('O'),
            ),
            Icon (Icons.heart_broken),
            Container(
              color: Colors.greenAccent,
              padding: EdgeInsets.all(30.0),
              child: Text('V'),
            ),
            Icon (Icons.heart_broken),
            Container(
              color: Colors.yellowAccent,
              padding: EdgeInsets.all(30.0),
              child: Text('E'),
            ),
          ]
      ),
    );

  }
}